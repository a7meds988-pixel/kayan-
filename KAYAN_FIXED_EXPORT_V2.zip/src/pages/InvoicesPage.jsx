
import React from "react";

const InvoicesPage = () => {
  return (
    <main style={{ padding: "2rem", textAlign: "center" }}>
      <h1>📄 فواتيري</h1>
      <p>دي صفحة الفواتير، ح نعرض فيها قائمة فواتيرك بالكامل.</p>
    </main>
  );
};

export default InvoicesPage;
