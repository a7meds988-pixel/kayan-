
import React from "react";

const CustomerPage = () => {
  return (
    <main style={{ padding: "2rem", textAlign: "center" }}>
      <h1>👤 صفحة العميل</h1>
      <p>دي صفحة عميل، ح نعرض فيها الفواتير والربح وكل التفاصيل.</p>
    </main>
  );
};

export default CustomerPage;
